//Account Paypal
1. Seller
email: ppc.seller@fpt.aptech.vn
password: 12345678

2. Buyer
email: buyer.15061997@gmail.com
password: 12345678


//Credit Card
Card Number: 4123123412345678
Expiration Date: 12/25
CVV: 123