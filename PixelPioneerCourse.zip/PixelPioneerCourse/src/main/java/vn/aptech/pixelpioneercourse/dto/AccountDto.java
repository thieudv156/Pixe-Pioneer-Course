package vn.aptech.pixelpioneercourse.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import vn.aptech.pixelpioneercourse.entities.Role;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class AccountDto {
    private int id;
    private String email;
    private String password;
    private String fullname;
    private String phone;
    private Role role;
}
