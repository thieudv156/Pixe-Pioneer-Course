package vn.aptech.pixelpioneercourse.entities;

public enum SubscriptionType {
    MONTHLY,
    YEARLY,
    UNLIMITED
}
