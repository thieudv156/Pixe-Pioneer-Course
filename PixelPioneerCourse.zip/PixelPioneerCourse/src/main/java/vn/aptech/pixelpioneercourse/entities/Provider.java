package vn.aptech.pixelpioneercourse.entities;

public enum Provider {
    LOCAL, GOOGLE
}
