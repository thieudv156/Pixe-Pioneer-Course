package vn.aptech.pixelpioneercourse.entities;

public enum PaymentMethod {
    CREDIT_CARD, PAYPAL
}
